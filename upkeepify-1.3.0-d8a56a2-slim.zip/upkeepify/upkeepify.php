<?php
/**
 * Plugin Name: Upkeepify
 * Plugin URI: https://github.com/anthonyhorne/upkeepify
 * Description: A comprehensive plugin to manage maintenance tasks within a complex. It supports task submissions with categorization, service provider management, and customizable settings.
 * Version: 1.3.0
 * Author: Anthony Horne
 * Text Domain: upkeepify
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * Credits:
 * - Anthony Horne: Plugin Development and Concept
 * - OpenAI's ChatGPT: Assistance with Code Examples and Logic (Sometimes Passive aggressively)
 * - WordPress Community: Various Tutorials and Code Snippets
 */

// Prevent direct file access
if (!defined('WPINC')) {
    die;
}

define('UPKEEPIFY_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('UPKEEPIFY_PLUGIN_URL', plugin_dir_url(__FILE__));
define('UPKEEPIFY_VERSION', '1.3.0');

// Include constants first
require_once UPKEEPIFY_PLUGIN_DIR . 'includes/constants.php';

// Include caching system
require_once UPKEEPIFY_PLUGIN_DIR . 'includes/caching.php';

// Meta registry + validation + migrations
require_once UPKEEPIFY_PLUGIN_DIR . 'includes/meta-registry.php';
require_once UPKEEPIFY_PLUGIN_DIR . 'includes/data-validation.php';
require_once UPKEEPIFY_PLUGIN_DIR . 'includes/migrations.php';

// Include component files
require_once UPKEEPIFY_PLUGIN_DIR . 'includes/custom-post-types.php';
require_once UPKEEPIFY_PLUGIN_DIR . 'includes/taxonomies.php';
require_once UPKEEPIFY_PLUGIN_DIR . 'includes/settings.php';
require_once UPKEEPIFY_PLUGIN_DIR . 'includes/shortcodes.php';
require_once UPKEEPIFY_PLUGIN_DIR . 'includes/utility-functions.php';
require_once UPKEEPIFY_PLUGIN_DIR . 'includes/admin-functions.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/sample-data.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/task-response-handling.php';

// Include the upload handlers file
require_once plugin_dir_path(__FILE__) . 'includes/upload-handlers.php';
require_once plugin_dir_path(__FILE__) . 'includes/notification-system.php';

// Include database optimization helpers
require_once plugin_dir_path(__FILE__) . 'includes/database-optimization.php';

// Trustee approval flows (token-based, login-free)
require_once UPKEEPIFY_PLUGIN_DIR . 'includes/trustee-approval.php';

// Progressive Web App support
require_once UPKEEPIFY_PLUGIN_DIR . 'includes/pwa.php';

// Activation and deactivation hooks
register_activation_hook(__FILE__, 'upkeepify_activate');
register_deactivation_hook(__FILE__, 'upkeepify_deactivate');

/**
 * Load text domain for localization.
 *
 * Loads the plugin's translation files for internationalization support.
 * Translation files should be placed in the /languages/ directory.
 *
 * @since 1.0
 * @uses load_plugin_textdomain()
 * @hook plugins_loaded
 */
function upkeepify_load_textdomain() {
    load_plugin_textdomain( 'upkeepify', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
}
add_action( 'plugins_loaded', 'upkeepify_load_textdomain' );

/**
 * Start PHP session early so the Set-Cookie header can be sent before output begins.
 * The shortcode-level session_start() calls are no-ops once this runs.
 *
 * @since 1.2.1
 * @hook init
 */
function upkeepify_session_start() {
    if ( session_status() === PHP_SESSION_NONE && ! headers_sent() ) {
        session_start();
    }
}
add_action( 'init', 'upkeepify_session_start', 1 );

/**
 * Plugin activation callback.
 *
 * Fires when the plugin is activated. Handles initialization tasks
 * such as inserting sample data.
 *
 * @since 1.0
 * @hook register_activation_hook
 * @uses upkeepify_maybe_insert_sample_data()
 */
function upkeepify_activate() {
    // Ensure logical schema and defaults exist
    upkeepify_setup_database();

    // Run any pending migrations
    upkeepify_run_migrations();

    // Optionally insert sample data
    upkeepify_maybe_insert_sample_data();

    // Schedule daily trustee reminder cron
    upkeepify_schedule_trustee_reminders();

    // Register PWA rewrite rules then flush so they take effect immediately.
    upkeepify_pwa_add_rewrite_rules();
    flush_rewrite_rules();
}

/**
 * Plugin deactivation callback.
 *
 * Fires when the plugin is deactivated. Handles cleanup tasks if needed.
 *
 * @since 1.0
 * @hook register_deactivation_hook
 */
function upkeepify_deactivate() {
    upkeepify_unschedule_trustee_reminders();
    flush_rewrite_rules();
}

// Ensure cron is scheduled on every load (in case it was cleared externally).
add_action( 'wp', 'upkeepify_schedule_trustee_reminders' );

/**
 * Add favicon to the site.
 *
 * Adds a custom favicon to both the front-end and admin areas.
 * The favicon is loaded from the plugin's root directory.
 *
 * @since 1.0
 * @uses plugins_url()
 * @hook wp_head
 * @hook admin_head
 */
function upkeepify_add_favicon() {
    echo '<link rel="icon" type="image/png" href="' . esc_url( plugins_url( 'favicon.png', __FILE__ ) ) . '" />';
}
add_action('wp_head', 'upkeepify_add_favicon');
add_action('admin_head', 'upkeepify_add_favicon'); // Also for admin area

/**
 * Fallback handler to ensure sample data is inserted.
 *
 * Checks if sample data has been inserted and inserts it if not.
 * This runs on admin_init as a safety mechanism. Includes error handling.
 *
 * @since 1.0
 * @uses get_option()
 * @uses update_option()
 * @uses upkeepify_insert_sample_data()
 * @hook admin_init
 */
function upkeepify_maybe_insert_sample_data_fallback() {
    try {
        // Check if sample data has already been marked as inserted
        $sample_data_inserted = get_option(UPKEEPIFY_OPTION_SAMPLE_DATA_INSERTED, false);

        if (!$sample_data_inserted) {
            if (WP_DEBUG) {
                error_log('Upkeepify Fallback: Starting sample data insertion');
            }

            // Insert sample data
            $result = upkeepify_insert_sample_data();

            // Mark as inserted only if successful
            if ($result) {
                update_option(UPKEEPIFY_OPTION_SAMPLE_DATA_INSERTED, time());
                if (WP_DEBUG) {
                    error_log('Upkeepify Fallback: Successfully completed sample data insertion');
                }
            } else {
                error_log('Upkeepify Fallback Warning: Sample data insertion completed with errors. Will retry on next admin_init.');
                // Don't mark as inserted if there were errors, so we can retry
            }
        } else {
            if (WP_DEBUG) {
                error_log('Upkeepify Fallback: Sample data already inserted at ' . date('Y-m-d H:i:s', $sample_data_inserted));
            }
        }
    } catch (Exception $e) {
        error_log('Upkeepify Fallback Exception: ' . $e->getMessage());
        // Don't mark as inserted on exception, allowing retry
    }
}

add_action('admin_init', 'upkeepify_maybe_insert_sample_data_fallback');
