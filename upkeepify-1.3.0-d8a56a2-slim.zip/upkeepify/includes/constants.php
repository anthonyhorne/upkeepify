<?php
/**
 * Constants Definition File
 *
 * This file centralizes all magic strings used throughout the Upkeepify plugin.
 *
 * @package Upkeepify
 */

// Prevent direct file access
if (!defined('WPINC')) {
    die;
}

/**
 * Logical schema version for Upkeepify data stored in WordPress tables.
 *
 * Increment this when introducing breaking/structural changes to:
 * - custom post types/taxonomies
 * - option structures
 * - meta key formats
 *
 * @since 1.0
 */
define('UPKEEPIFY_DB_VERSION', 2);

// Migration/Schema Option Names
define('UPKEEPIFY_OPTION_DB_VERSION', 'upkeepify_db_version');
define('UPKEEPIFY_OPTION_MIGRATION_HISTORY', 'upkeepify_migration_history');
define('UPKEEPIFY_OPTION_MIGRATION_LOG', 'upkeepify_migration_log');
define('UPKEEPIFY_OPTION_BACKUP_HISTORY', 'upkeepify_backup_history');

// Post Type Slugs
define('UPKEEPIFY_POST_TYPE_MAINTENANCE_TASKS', 'maintenance_tasks');
define('UPKEEPIFY_POST_TYPE_RESPONSES', 'upkeepify_responses');
define('UPKEEPIFY_POST_TYPE_PROVIDER_RESPONSES', 'provider_responses');

// Taxonomy Slugs
define('UPKEEPIFY_TAXONOMY_SERVICE_PROVIDER', 'service_provider');
define('UPKEEPIFY_TAXONOMY_TASK_CATEGORY', 'task_category');
define('UPKEEPIFY_TAXONOMY_TASK_TYPE', 'task_type');
define('UPKEEPIFY_TAXONOMY_TASK_STATUS', 'task_status');
define('UPKEEPIFY_TAXONOMY_UNIT', 'unit');

// Meta Box IDs
define('UPKEEPIFY_META_BOX_NEAREST_UNIT', 'upkeepify_nearest_unit');
define('UPKEEPIFY_META_BOX_ROUGH_ESTIMATE', 'upkeepify_rough_estimate');

// Meta Keys (Post Meta)
define('UPKEEPIFY_META_KEY_NEAREST_UNIT', 'upkeepify_nearest_unit');
define('UPKEEPIFY_META_KEY_ROUGH_ESTIMATE', 'upkeepify_rough_estimate');
define('UPKEEPIFY_META_KEY_GPS_LATITUDE', 'upkeepify_gps_latitude');
define('UPKEEPIFY_META_KEY_GPS_LONGITUDE', 'upkeepify_gps_longitude');
define('UPKEEPIFY_META_KEY_TASK_UPDATE_TOKEN', '_upkeepify_task_update_token');
define('UPKEEPIFY_META_KEY_ASSIGNED_SERVICE_PROVIDER', 'assigned_service_provider');
define('UPKEEPIFY_META_KEY_DUE_DATE', 'due_date');

// Term Meta Keys
define('UPKEEPIFY_TERM_META_PROVIDER_PHONE', 'provider_phone');
define('UPKEEPIFY_TERM_META_PROVIDER_EMAIL', 'provider_email');
define('UPKEEPIFY_TERM_META_ASSOCIATED_CATEGORIES', 'associated_task_categories');

// Response Post Meta Keys
define('UPKEEPIFY_META_KEY_RESPONSE_TASK_ID', 'response_task_id');
define('UPKEEPIFY_META_KEY_PROVIDER_ID', 'provider_id');
define('UPKEEPIFY_META_KEY_RESPONSE_TOKEN', 'response_token');
define('UPKEEPIFY_META_KEY_RESPONSE_TOKEN_EXPIRES', 'response_token_expires');
define('UPKEEPIFY_META_KEY_RESPONSE_TOKEN_REVOKED_AT', 'response_token_revoked_at');
define('UPKEEPIFY_META_KEY_RESPONSE_TOKEN_REGENERATED_AT', 'response_token_regenerated_at');
define('UPKEEPIFY_META_KEY_RESPONSE_TOKEN_REGENERATED_BY', 'response_token_regenerated_by');

// Structured estimate meta keys (set when contractor submits Step 2 form)
define('UPKEEPIFY_META_KEY_RESPONSE_DECISION',            'response_decision');            // 'accept' | 'decline'
define('UPKEEPIFY_META_KEY_RESPONSE_ESTIMATE',            'response_estimate');            // numeric ballpark
define('UPKEEPIFY_META_KEY_RESPONSE_ESTIMATE_LOW',        'response_estimate_low');        // optional range low
define('UPKEEPIFY_META_KEY_RESPONSE_ESTIMATE_HIGH',       'response_estimate_high');       // optional range high
define('UPKEEPIFY_META_KEY_RESPONSE_ESTIMATE_CONFIDENCE', 'response_estimate_confidence'); // 'low'|'medium'|'high'
define('UPKEEPIFY_META_KEY_RESPONSE_AVAILABILITY',        'response_availability');        // Y-m-d earliest date
define('UPKEEPIFY_META_KEY_RESPONSE_NOTE',                'response_note');                // short note ≤500 chars

// Formal quote + completion meta keys (set in Step 3 form)
define('UPKEEPIFY_META_KEY_RESPONSE_FORMAL_QUOTE',        'response_formal_quote');        // numeric formal quote
define('UPKEEPIFY_META_KEY_RESPONSE_QUOTE_NOTE',          'response_quote_note');          // quote conditions ≤500 chars
define('UPKEEPIFY_META_KEY_RESPONSE_QUOTE_ATTACHMENTS',   'response_quote_attachments');   // serialized formal quote attachment ID array
define('UPKEEPIFY_META_KEY_RESPONSE_COMPLETED_AT',        'response_completed_at');        // Unix timestamp of completion
define('UPKEEPIFY_META_KEY_RESPONSE_COMPLETION_PHOTOS',   'response_completion_photos');   // serialized attachment ID array
define('UPKEEPIFY_META_KEY_RESPONSE_COMPLETION_NOTE',     'response_completion_note');     // completion note ≤500 chars

// Admin actions — Step 3
define('UPKEEPIFY_ADMIN_ACTION_PROVIDER_QUOTE_SUBMIT',      'upkeepify_provider_quote_submit');
define('UPKEEPIFY_ADMIN_ACTION_PROVIDER_COMPLETION_SUBMIT', 'upkeepify_provider_completion_submit');

// Nonce names — Step 3
define('UPKEEPIFY_NONCE_PROVIDER_QUOTE',             'upkeepify_provider_quote_nonce');
define('UPKEEPIFY_NONCE_PROVIDER_COMPLETION',        'upkeepify_provider_completion_nonce');
define('UPKEEPIFY_NONCE_ACTION_PROVIDER_QUOTE',      'upkeepify_provider_quote_action');
define('UPKEEPIFY_NONCE_ACTION_PROVIDER_COMPLETION', 'upkeepify_provider_completion_action');

// Contractor invite
define('UPKEEPIFY_SETTING_PROVIDER_RESPONSE_PAGE', 'upkeepify_provider_response_page');
define('UPKEEPIFY_TOKEN_EXPIRY_DAYS', 14);
define('UPKEEPIFY_QUERY_VAR_TOKEN', 'upkeepify_token');

// Resident confirmation (Step 4)
define('UPKEEPIFY_META_KEY_TASK_SUBMITTER_EMAIL',       '_upkeepify_submitter_email');        // resident email captured at task submission
define('UPKEEPIFY_META_KEY_TASK_RESIDENT_TOKEN',        '_upkeepify_resident_token');         // token for resident confirmation link
define('UPKEEPIFY_META_KEY_TASK_RESIDENT_CONFIRMED',    '_upkeepify_resident_confirmed');     // '1' = satisfied, '0' = not satisfied
define('UPKEEPIFY_META_KEY_TASK_RESIDENT_CONFIRMED_AT', '_upkeepify_resident_confirmed_at'); // Unix timestamp of confirmation
define('UPKEEPIFY_META_KEY_TASK_RESIDENT_CONFIRM_NOTE', '_upkeepify_resident_confirm_note'); // optional resident note (≤500 chars)
define('UPKEEPIFY_META_KEY_TASK_RESIDENT_FOLLOWUP_STATUS', '_upkeepify_resident_followup_status'); // resident_issue|contractor_followup_submitted
define('UPKEEPIFY_META_KEY_TASK_RESIDENT_FOLLOWUP_RESPONSE_ID', '_upkeepify_resident_followup_response_id'); // provider response handling the follow-up
define('UPKEEPIFY_META_KEY_TASK_RESIDENT_ISSUE_REPORTED_AT', '_upkeepify_resident_issue_reported_at'); // Unix timestamp of resident issue report
define('UPKEEPIFY_META_KEY_TASK_RESIDENT_ISSUE_CONTRACTOR_NOTIFIED_AT', '_upkeepify_resident_issue_contractor_notified_at'); // Unix timestamp of contractor notice
define('UPKEEPIFY_META_KEY_TASK_RESIDENT_ISSUE_RESOLVED_AT', '_upkeepify_resident_issue_resolved_at'); // Unix timestamp of trustee issue resolution
define('UPKEEPIFY_META_KEY_TASK_RESIDENT_ISSUE_RESOLVED_BY', '_upkeepify_resident_issue_resolved_by'); // WP user ID that resolved the resident issue
define('UPKEEPIFY_META_KEY_TASK_RESIDENT_ISSUE_RESOLUTION_NOTE', '_upkeepify_resident_issue_resolution_note'); // optional trustee resolution note (≤500 chars)
define('UPKEEPIFY_META_KEY_TASK_MANUAL_CLOSED_AT', '_upkeepify_manual_closed_at'); // Unix timestamp of trustee manual lifecycle close
define('UPKEEPIFY_META_KEY_TASK_MANUAL_CLOSED_BY', '_upkeepify_manual_closed_by'); // WP user ID that manually closed the lifecycle
define('UPKEEPIFY_META_KEY_TASK_MANUAL_CLOSE_MODE', '_upkeepify_manual_close_mode'); // resident_confirmed|closed_without_confirmation
define('UPKEEPIFY_META_KEY_TASK_MANUAL_CLOSE_NOTE', '_upkeepify_manual_close_note'); // optional trustee manual close note (≤500 chars)
define('UPKEEPIFY_META_KEY_TASK_APPROVED_ESTIMATE_RESPONSE_ID', '_upkeepify_approved_estimate_response_id'); // provider response approved for formal quote
define('UPKEEPIFY_META_KEY_TASK_APPROVED_ESTIMATE_AT', '_upkeepify_approved_estimate_at'); // Unix timestamp of estimate approval
define('UPKEEPIFY_META_KEY_TASK_APPROVED_ESTIMATE_BY', '_upkeepify_approved_estimate_by'); // WP user ID that approved estimate
define('UPKEEPIFY_META_KEY_TASK_APPROVED_QUOTE_RESPONSE_ID', '_upkeepify_approved_quote_response_id'); // provider response approved for work/completion
define('UPKEEPIFY_META_KEY_TASK_APPROVED_QUOTE_AT', '_upkeepify_approved_quote_at'); // Unix timestamp of quote approval
define('UPKEEPIFY_META_KEY_TASK_APPROVED_QUOTE_BY', '_upkeepify_approved_quote_by'); // WP user ID that approved quote
define('UPKEEPIFY_SETTING_RESIDENT_CONFIRMATION_PAGE',  'upkeepify_resident_confirmation_page');
define('UPKEEPIFY_QUERY_VAR_RESIDENT_TOKEN',            'upkeepify_resident_token');
define('UPKEEPIFY_SHORTCODE_RESIDENT_CONFIRMATION_FORM', 'upkeepify_resident_confirmation_form');
define('UPKEEPIFY_ADMIN_ACTION_RESIDENT_CONFIRM_SUBMIT', 'upkeepify_resident_confirm_submit');
define('UPKEEPIFY_NONCE_RESIDENT_CONFIRM',               'upkeepify_resident_confirm_nonce');
define('UPKEEPIFY_NONCE_ACTION_RESIDENT_CONFIRM',        'upkeepify_resident_confirm_action');
define('UPKEEPIFY_RESIDENT_FOLLOWUP_STATUS_ISSUE',       'resident_issue');
define('UPKEEPIFY_RESIDENT_FOLLOWUP_STATUS_SUBMITTED',   'contractor_followup_submitted');
define('UPKEEPIFY_MANUAL_CLOSE_MODE_RESIDENT_CONFIRMED', 'resident_confirmed');
define('UPKEEPIFY_MANUAL_CLOSE_MODE_CLOSED_WITHOUT_CONFIRMATION', 'closed_without_confirmation');

// Contractor follow-up after resident dissatisfaction.
define('UPKEEPIFY_META_KEY_RESPONSE_FOLLOWUP_COMPLETED_AT', 'response_followup_completed_at');
define('UPKEEPIFY_META_KEY_RESPONSE_FOLLOWUP_NOTE',         'response_followup_note');
define('UPKEEPIFY_META_KEY_RESPONSE_FOLLOWUP_PHOTOS',       'response_followup_photos');

// Option Names
define('UPKEEPIFY_OPTION_SETTINGS', 'upkeepify_settings');
define('UPKEEPIFY_OPTION_SAMPLE_DATA_INSERTED', 'upkeepify_sample_data_inserted');
define('UPKEEPIFY_OPTION_NOTIFICATIONS', 'upkeepify_notifications');

// Settings Keys
define('UPKEEPIFY_SETTING_SMTP_OPTION', 'upkeepify_smtp_option');
define('UPKEEPIFY_SETTING_SMTP_HOST', 'upkeepify_smtp_host');
define('UPKEEPIFY_SETTING_NOTIFY_OPTION', 'upkeepify_notify_option');
define('UPKEEPIFY_SETTING_PROVIDER_DELETE_TASK', 'upkeepify_provider_delete_task');
define('UPKEEPIFY_SETTING_PUBLIC_TASK_LOGGING', 'upkeepify_public_task_logging');
define('UPKEEPIFY_SETTING_OVERRIDE_EMAIL', 'upkeepify_override_email');
define('UPKEEPIFY_SETTING_AUDIT_EMAIL', 'upkeepify_audit_email');
define('UPKEEPIFY_SETTING_ENABLE_TOKEN_UPDATE', 'upkeepify_enable_token_update');
define('UPKEEPIFY_SETTING_NUMBER_OF_UNITS', 'upkeepify_number_of_units');
define('UPKEEPIFY_SETTING_CURRENCY', 'upkeepify_currency');
define('UPKEEPIFY_SETTING_ENABLE_THANK_YOU_PAGE', 'upkeepify_enable_thank_you_page');
define('UPKEEPIFY_SETTING_THANK_YOU_PAGE_URL', 'upkeepify_thank_you_page_url');
define('UPKEEPIFY_SETTING_NOTIFY_CONTRACTOR_ON_RESIDENT_ISSUE', 'upkeepify_notify_contractor_on_resident_issue');

// Shortcode Names
define('UPKEEPIFY_SHORTCODE_MAINTENANCE_TASKS', 'maintenance_tasks');
define('UPKEEPIFY_SHORTCODE_LIST_TASKS', 'upkeepify_list_tasks');
define('UPKEEPIFY_SHORTCODE_TASK_FORM', 'upkeepify_task_form');
define('UPKEEPIFY_SHORTCODE_PROVIDER_RESPONSE_FORM', 'upkeepify_provider_response_form');
define('UPKEEPIFY_SHORTCODE_TASKS_BY_CATEGORY', 'upkeepify_tasks_by_category');
define('UPKEEPIFY_SHORTCODE_TASKS_BY_PROVIDER', 'upkeepify_tasks_by_provider');
define('UPKEEPIFY_SHORTCODE_TASKS_BY_STATUS', 'upkeepify_tasks_by_status');
define('UPKEEPIFY_SHORTCODE_TASK_SUMMARY', 'upkeepify_task_summary');
define('UPKEEPIFY_SHORTCODE_TASK_CALENDAR', 'upkeepify_task_calendar');

// Nonce Names
define('UPKEEPIFY_NONCE_NEAREST_UNIT', 'upkeepify_nearest_unit_nonce');
define('UPKEEPIFY_NONCE_ROUGH_ESTIMATE', 'upkeepify_rough_estimate_nonce');
define('UPKEEPIFY_NONCE_TRUSTEE_LIFECYCLE', 'upkeepify_trustee_lifecycle_nonce');
define('UPKEEPIFY_NONCE_TASK_SUBMIT', 'upkeepify_task_submit_nonce');
define('UPKEEPIFY_NONCE_RUN_MIGRATIONS', 'upkeepify_run_migrations_nonce');
define('UPKEEPIFY_NONCE_DB_TOOLS', 'upkeepify_db_tools_nonce');
define('UPKEEPIFY_NONCE_PROVIDER_RESPONSE', 'upkeepify_provider_response_nonce');
define('UPKEEPIFY_NONCE_CREATE_DEFAULT_PAGES', 'upkeepify_create_default_pages_nonce');

// Nonce Actions
define('UPKEEPIFY_NONCE_ACTION_NEAREST_UNIT_SAVE', 'upkeepify_nearest_unit_save');
define('UPKEEPIFY_NONCE_ACTION_ROUGH_ESTIMATE_SAVE', 'upkeepify_rough_estimate_save');
define('UPKEEPIFY_NONCE_ACTION_TRUSTEE_LIFECYCLE', 'upkeepify_trustee_lifecycle_action');
define('UPKEEPIFY_NONCE_ACTION_TASK_SUBMIT', 'upkeepify_task_submit_action');
define('UPKEEPIFY_NONCE_ACTION_RUN_MIGRATIONS', 'upkeepify_run_migrations');
define('UPKEEPIFY_NONCE_ACTION_DB_TOOLS', 'upkeepify_db_tools');
define('UPKEEPIFY_NONCE_ACTION_PROVIDER_RESPONSE', 'upkeepify_provider_response_action');
define('UPKEEPIFY_NONCE_ACTION_CREATE_DEFAULT_PAGES', 'upkeepify_create_default_pages');

// Post Type Labels
define('UPKEEPIFY_LABEL_MAINTENANCE_TASKS', 'Maintenance Tasks');
define('UPKEEPIFY_LABEL_RESPONSES', 'Responses');
define('UPKEEPIFY_LABEL_RESPONSE', 'Response');
define('UPKEEPIFY_LABEL_PROVIDER_RESPONSES', 'Provider Responses');

// Taxonomy Labels
define('UPKEEPIFY_LABEL_SERVICE_PROVIDERS', 'Service Providers');
define('UPKEEPIFY_LABEL_TASK_CATEGORIES', 'Task Categories');
define('UPKEEPIFY_LABEL_TASK_TYPES', 'Task Types');
define('UPKEEPIFY_LABEL_TASK_STATUSES', 'Task Statuses');
define('UPKEEPIFY_LABEL_UNITS', 'Units');

// Lifecycle task status labels/slugs.
define('UPKEEPIFY_TASK_STATUS_PENDING_TASK_APPROVAL', 'Pending Task Approval');
define('UPKEEPIFY_TASK_STATUS_OPEN', 'Open');
define('UPKEEPIFY_TASK_STATUS_PENDING_ESTIMATE_APPROVAL', 'Pending Estimate Approval');
define('UPKEEPIFY_TASK_STATUS_PENDING_QUOTE_APPROVAL', 'Pending Quote Approval');
define('UPKEEPIFY_TASK_STATUS_AWAITING_COMPLETION', 'Awaiting Completion');
define('UPKEEPIFY_TASK_STATUS_AWAITING_RESIDENT_CONFIRMATION', 'Awaiting Resident Confirmation');
define('UPKEEPIFY_TASK_STATUS_NEEDS_REVIEW', 'Needs Review');
define('UPKEEPIFY_TASK_STATUS_COMPLETED', 'Completed');
define('UPKEEPIFY_TASK_STATUS_ON_HOLD', 'On Hold');
define('UPKEEPIFY_TASK_STATUS_REJECTED', 'Rejected');
define('UPKEEPIFY_TASK_STATUS_SLUG_PENDING_TASK_APPROVAL', 'pending-task-approval');
define('UPKEEPIFY_TASK_STATUS_SLUG_PENDING_ESTIMATE_APPROVAL', 'pending-estimate-approval');
define('UPKEEPIFY_TASK_STATUS_SLUG_PENDING_QUOTE_APPROVAL', 'pending-quote-approval');
define('UPKEEPIFY_TASK_STATUS_SLUG_AWAITING_COMPLETION', 'awaiting-completion');
define('UPKEEPIFY_TASK_STATUS_SLUG_AWAITING_RESIDENT_CONFIRMATION', 'awaiting-resident-confirmation');
define('UPKEEPIFY_TASK_STATUS_SLUG_NEEDS_REVIEW', 'needs-review');
define('UPKEEPIFY_TASK_STATUS_SLUG_REJECTED', 'rejected');

// Form Field Names
define('UPKEEPIFY_FORM_FIELD_TASK_SUBMIT', 'upkeepify_task_submit');
define('UPKEEPIFY_FORM_FIELD_MATH', 'math');
define('UPKEEPIFY_FORM_FIELD_TASK_TITLE', 'task_title');
define('UPKEEPIFY_FORM_FIELD_TASK_DESCRIPTION', 'task_description');
define('UPKEEPIFY_FORM_FIELD_NEAREST_UNIT', 'nearest_unit');

// Session Keys
define('UPKEEPIFY_SESSION_MATH_RESULT', 'upkeepify_math_result');

// File Upload Limits
define('UPKEEPIFY_MAX_UPLOAD_SIZE', 2 * 1024 * 1024); // 2MB
define('UPKEEPIFY_MAX_QUOTE_UPLOAD_SIZE', 5 * 1024 * 1024); // 5MB

// Admin Actions
define('UPKEEPIFY_ADMIN_ACTION_PROVIDER_RESPONSE_SUBMIT', 'upkeepify_provider_response_submit');
define('UPKEEPIFY_ADMIN_ACTION_TRUSTEE_LIFECYCLE_APPROVAL', 'upkeepify_trustee_lifecycle_approval');
define('UPKEEPIFY_ADMIN_ACTION_TRUSTEE_LIFECYCLE_FOLLOWUP', 'upkeepify_trustee_lifecycle_followup');
define('UPKEEPIFY_ADMIN_ACTION_PROVIDER_TOKEN_MANAGE', 'upkeepify_provider_token_manage');
define('UPKEEPIFY_ADMIN_ACTION_TRUSTEE_MANUAL_CLOSE', 'upkeepify_trustee_manual_close');
define('UPKEEPIFY_ADMIN_ACTION_RUN_MIGRATIONS', 'upkeepify_run_migrations');
define('UPKEEPIFY_ADMIN_ACTION_REPAIR_SCHEMA', 'upkeepify_repair_schema');
define('UPKEEPIFY_ADMIN_ACTION_RESET_DATABASE', 'upkeepify_reset_database');
define('UPKEEPIFY_ADMIN_ACTION_BACKUP_DATABASE', 'upkeepify_backup_database');
define('UPKEEPIFY_ADMIN_ACTION_EXPORT_ALL_DATA', 'upkeepify_export_all_data');
define('UPKEEPIFY_ADMIN_ACTION_EXPORT_SETTINGS', 'upkeepify_export_settings');
define('UPKEEPIFY_ADMIN_ACTION_IMPORT_ALL_DATA', 'upkeepify_import_all_data');
define('UPKEEPIFY_ADMIN_ACTION_ROLLBACK_LAST_MIGRATION', 'upkeepify_rollback_last_migration');
define('UPKEEPIFY_ADMIN_ACTION_CREATE_DEFAULT_PAGES', 'upkeepify_create_default_pages');

// Menu Slugs
define('UPKEEPIFY_MENU_SETTINGS_PAGE', 'upkeepify_settings');
define('UPKEEPIFY_MENU_SETUP_WIZARD_PAGE', 'upkeepify_setup_wizard');
define('UPKEEPIFY_MENU_DB_HEALTH_PAGE', 'upkeepify_db_health');

// Cache Groups
define('UPKEEPIFY_CACHE_GROUP', 'upkeepify');
define('UPKEEPIFY_CACHE_GROUP_SETTINGS', 'upkeepify_settings');
define('UPKEEPIFY_CACHE_GROUP_TERMS', 'upkeepify_terms');
define('UPKEEPIFY_CACHE_GROUP_SHORTCODES', 'upkeepify_shortcodes');
define('UPKEEPIFY_CACHE_GROUP_QUERIES', 'upkeepify_queries');

// Cache Expiration Times (in seconds)
define('UPKEEPIFY_CACHE_EXPIRE_SHORT', 1800); // 30 minutes
define('UPKEEPIFY_CACHE_EXPIRE_MEDIUM', 3600); // 1 hour
define('UPKEEPIFY_CACHE_EXPIRE_LONG', 7200); // 2 hours
define('UPKEEPIFY_CACHE_EXPIRE_VERY_LONG', 21600); // 6 hours

// Trustee approval steps
define('UPKEEPIFY_TRUSTEE_STEP_TASK',     'task_approval');
define('UPKEEPIFY_TRUSTEE_STEP_ESTIMATE', 'estimate_approval');
define('UPKEEPIFY_TRUSTEE_STEP_QUOTE',    'quote_approval');

// Trustee token expiry
define('UPKEEPIFY_TRUSTEE_TOKEN_EXPIRY_DAYS', 30);

// Trustee approval meta keys (all stored as serialized arrays keyed by step)
define('UPKEEPIFY_META_KEY_TRUSTEE_TOKENS',               '_upkeepify_trustee_tokens');               // [step][email] => token
define('UPKEEPIFY_META_KEY_TRUSTEE_APPROVALS',            '_upkeepify_trustee_approvals');            // [step][email] => timestamp
define('UPKEEPIFY_META_KEY_TRUSTEE_REJECTIONS',           '_upkeepify_trustee_rejections');           // [step][email] => timestamp
define('UPKEEPIFY_META_KEY_TRUSTEE_APPROVAL_REQUESTED_AT','_upkeepify_trustee_approval_requested_at');// [step] => timestamp
define('UPKEEPIFY_META_KEY_TRUSTEE_REMINDER_COUNTS',      '_upkeepify_trustee_reminder_counts');      // [step] => int
define('UPKEEPIFY_META_KEY_TRUSTEE_REJECTION_INFO',       '_upkeepify_trustee_rejection_info');       // serialized: step/email/at
define('UPKEEPIFY_META_KEY_TASK_APPROVED_TASK_AT',        '_upkeepify_approved_task_at');             // Unix timestamp
define('UPKEEPIFY_META_KEY_TASK_APPROVED_TASK_BY',        '_upkeepify_approved_task_by');             // serialized array of emails

// Trustee approval query var / action / shortcode / nonce
define('UPKEEPIFY_QUERY_VAR_TRUSTEE_TOKEN',          'upkeepify_trustee_token');
define('UPKEEPIFY_ADMIN_ACTION_TRUSTEE_APPROVAL_SUBMIT', 'upkeepify_trustee_approval_submit');
define('UPKEEPIFY_SHORTCODE_TRUSTEE_APPROVAL_FORM',  'upkeepify_trustee_approval');
define('UPKEEPIFY_NONCE_TRUSTEE_APPROVAL',           'upkeepify_trustee_approval_nonce');
define('UPKEEPIFY_NONCE_ACTION_TRUSTEE_APPROVAL',    'upkeepify_trustee_approval_action');

// Trustee approval cron hook
define('UPKEEPIFY_CRON_TRUSTEE_REMINDERS', 'upkeepify_trustee_approval_reminders');

// Trustee approval settings keys
define('UPKEEPIFY_SETTING_TRUSTEE_EMAILS',             'upkeepify_trustee_emails');
define('UPKEEPIFY_SETTING_TRUSTEE_REQUIRED_APPROVALS', 'upkeepify_trustee_required_approvals');
define('UPKEEPIFY_SETTING_TRUSTEE_REJECT_KILLS',       'upkeepify_trustee_reject_kills');
define('UPKEEPIFY_SETTING_TRUSTEE_REMINDER_COUNT',     'upkeepify_trustee_reminder_count');
define('UPKEEPIFY_SETTING_TRUSTEE_REMINDER_INTERVAL',  'upkeepify_trustee_reminder_interval');
define('UPKEEPIFY_SETTING_TRUSTEE_APPROVAL_PAGE',      'upkeepify_trustee_approval_page');
